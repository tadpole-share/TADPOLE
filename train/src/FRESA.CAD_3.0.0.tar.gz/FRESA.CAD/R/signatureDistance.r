signatureDistance <- 
function (template, data=NULL, method = c("pearson","spearman","kendall","EUQ","MAN"))
{

#given the template: mean,median,sample, etc....;signatureDistance it will return the distance between the template to each row of the dataframe
#the template is a named numeric vector
#the data is a colnamed data frame
#methods:
# EUQ: (euclidian distance)/sd
# MAN: (Manhattan distance)/IQR
# pearson: 1-Pearson correlation coefficient
# spearman: 1-spearman correlation coefficient
# kendall: 1-kendall correlation coefficient

	method <- match.arg(method)
	datasubset <- as.matrix(data[,names(template)]);
	switch(method, 
		EUQ = 
		{ 
			eqDistance <- function (x,template,istd) {md <- sqrt(mean((x-template)^2,na.rm=TRUE))*istd; return (md)}
			isdt <- 1.0/sd(template);
			metric <- apply(datasubset,1,eqDistance,template=template,istd=isdt);
		},
		MAN = 
		{ 
			manDistance <- function (x,template,iiqr) {md <- mean(abs(x-template),na.rm=TRUE)*iiqr; return (md)}
			iiqr <- 1.0/IQR(template);
			metric <- apply(datasubset,1,manDistance,template=template,iiqr=iiqr);
	  },
		{
			corDistance <- function (x,template,method) {md <- 1.0-cor(x,template,method=method,use="pairwise.complete.obs"); return (md)}
			metric <- apply(datasubset,1,corDistance,template=template,method=method);
		}
	)
	names(metric) <- rownames(data);
	
  result <- metric
	return (result);
}
