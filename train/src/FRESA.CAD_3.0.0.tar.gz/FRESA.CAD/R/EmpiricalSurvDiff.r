EmpiricalSurvDiff<-function(times=times,status=status,groups=groups,samples=1000,type="SLR",plots=FALSE,minAproxSamples=100,computeDist=FALSE,...)
{

LogRankNormal<-function(times=times,status=status,groups=groups)
{
  LR <-.Call("logRank",times,status,groups);
  return (LR)
} 


SLRNullDistribution<-function(times=times,status=status,groups=groups,samples=1000,type=c("Chi","SLR"))
{
  type <- match.arg(type);
  logranksamples<-.Call("SLRNullDistribution",times,status,groups,samples,1+1*(type=="Chi"));
  return (logranksamples)
}

SLRDistribution<-function(times=times,status=status,groups=groups,samples=1000,type=c("Chi","SLR"))
{
  logranksamples<-.Call("SLRDistribution",times,status,groups,samples,1+1*(type=="Chi"));
  return (logranksamples)
}

SLRpvalue<-function(LR=LR,nullLR=NULL,LRDist=NULL,type="",minAproxSamples=100)
{
  
  pvalue=1;
  pequal=1;
  psup=1;
  pinf=1;
  if (type=="Chi")
  {
    LR <- LR$SLR^2;
    pvalue <- sum(nullLR>LR)/samples;
  }
  else
  {
    samples=length(nullLR);
    LR <- LR$SLR;
    nullLR <- nullLR[order(nullLR)];
    zvalue <- qnorm(minAproxSamples/samples);

    topcount <- sum(nullLR > abs(LR));
    lowcount <- sum(nullLR <= -abs(LR));

    
    phigh = 0;
    if (topcount>minAproxSamples) 
    {
      phigh <- topcount/samples;
    }
    else
    {
      LRATTop <- nullLR[samples-minAproxSamples+1];
      zhighgain <- abs(LRATTop/zvalue);
      phigh <- pnorm(abs(LR),0,zhighgain,FALSE);
    }

    plow = 0;
    if (lowcount>minAproxSamples) 
    {
      plow <- lowcount/samples;
    }
    else
    {
      LRATbottom <- nullLR[minAproxSamples];
      zlowgain <- LRATbottom/zvalue;
      plow <- pnorm(-abs(LR),0,zlowgain,TRUE);
    }
    pequal = plow+phigh;
    if (2.0*sum(nullLR < LR) > samples)
    {
      pvalue = phigh;
    }
    else
    {
      pvalue = plow;
    }
    if (is.null(LRDist))
    {
      if (LR>0)
      {
        psup <- plow;
        pinf <- 1.0-psup;
      }
      else
      {
        pinf <- phigh;
        psup <- 1.0-pinf;
      }
    }
    else
    {
      LRsamples=length(LRDist);
      mLR <- median(LRDist)
      sdLR <- sd(LRDist)
      LRDist <- LRDist[order(LRDist)];
      minAproxSamples = as.integer(0.2*LRsamples+0.5);
      zvalue <- abs(qnorm(0.2));
  
      topcount <- sum(LRDist > 0);
      lowcount <- sum(LRDist <= 0);

      
      phigh = 0;
      if (topcount > minAproxSamples) 
      {
        phigh <- topcount/LRsamples;
      }
      else
      {
        LRATTop <- LRDist[LRsamples-minAproxSamples+1];
        sigma <- (LRATTop-mLR)/zvalue;
        phigh <- pnorm(0,mLR,sigma,FALSE);
      }
      plow = 0;
      if (lowcount > minAproxSamples) 
      {
        plow <- lowcount/LRsamples;
      }
      else
      {
        LRATbottom <- LRDist[minAproxSamples];
        sigma <- (mLR-LRATbottom)/zvalue;
        plow <- pnorm(0,mLR,sigma,TRUE);
      }
      if (LR>0)
      {
        psup <- plow;
        pinf <- 1.0-psup;
      }
      else
      {
        pinf <- phigh;
        psup <- 1.0-pinf;
      }
    }
  }
  return (list(LR=LR,pvalue=pvalue,p.equal=pequal,p.sup=psup,p.inf=pinf))
}

  LRDist <- NULL;

  LR <- LogRankNormal(times,status,groups)
  nullLR <- SLRNullDistribution(times,status,groups,samples,type);
  if ((type=="SLR")&&(computeDist)) LRDist <- SLRDistribution(times,status,groups,samples);

  pvalues <- SLRpvalue(LR,nullLR,LRDist,type,minAproxSamples);
  if (plots)
  {
    smallnull <- nullLR[sample(samples,1000)]
    plot(ecdf(smallnull),main=sprintf("LR: %8.2f, p(LR=0)= %8.3e, p(|LR|<0)= %8.3e",LR$SLR,pvalues$p.equal,pvalues$pvalue),xlim=c(-6,6),col="black",lwd = 2,verticals = TRUE, do.points = FALSE,...);
    d=density(smallnull,bw="nrd")
    lines(d,col="blue")
    if (!is.null(LRDist))
    {
      smallnull <- LRDist[sample(samples,1000)]
      lines(ecdf(smallnull),col="red",lwd = 1,verticals = TRUE, do.points = FALSE);  
      d=density(smallnull,bw="nrd")
      lines(d,col="pink")
    }
    abline(v=LR$SLR,col = "red");
  }

  return (list(pvalue=pvalues$pvalue,LR=LR,p.equal=pvalues$p.equal,p.sup=pvalues$p.sup,p.inf=pvalues$p.inf,nullDist=nullLR,LRDist=LRDist))
}


