#' @method update fitFRESA
summary.fitFRESA <- function(object,type=c("Improvement","Residual"),ci=c(0.025,0.975),data=NULL,...)
{
	coefficients <- NULL;
	type <- match.arg(type);
	coffset <- 1.0*(object$type == "COX") 
	outcome <- as.character(all.vars(object$formula)[1+coffset]);
	FRESAsummary <- NULL;
	bv <- NULL;
	if (length(object$coefficients)>1)
	{
		if (is.null(data)) 
		{
			data <- object$model;
		}
		if ((object$type=="LM") || (type=="Residual"))
		{
			vres <- getVar.Res(object,data=data,Outcome=outcome,type=object$type);
			bv <- bootstrapValidation_Res(model.formula=object$formula,Outcome=outcome,data=data,type=object$type,...)
			coefficients <- object$coefficients[-1];
			ncoef <- length(coefficients);
			cis <- matrix(rep(0,ncoef*3),ncoef,3);
			coffset <- 1.0*(object$type != "COX") 
			for (i in 1:ncoef)
			{
				cis[i,] = as.vector(quantile(bv$s.coef[,i+coffset], probs = c(ci[1],0.5,ci[2]), na.rm = TRUE,names = FALSE, type = 7));
			}
			coefficients=cbind(coefficients,cis,vres$unitrainMSS,vres$redtrainMSS,vres$NeRIs,vres$FP.value,vres$tP.value,vres$BinP.value,vres$WilcoxP.value);
			colnames(coefficients) <- c("Estimate","lower","median","upper","u.MSS","r.MSS","NeRI","F.pvalue","t.pvalue","Sign.pvalue","Wilcox.pvalue");
			Rsquare <- var(object$response[,1]);
			Rsquare <- (Rsquare-vres$FullTrainMSS)/Rsquare;
			FRESAsummary <- list(coefficients=coefficients,MSS=vres$FullTrainMSS,R2=Rsquare,bootstrap=bv);
		}
		else
		{
			vres <- getVar.Bin(object,data=data,Outcome=outcome,type=object$type);
			bv <- bootstrapValidation_Bin(model.formula=object$formula,Outcome=outcome,data=data,type=object$type,...)
			coefficients <- object$coefficients[-1];
			ncoef <- length(coefficients);
			cis <- matrix(rep(0,ncoef*3),ncoef,3);
			coffset <- 1.0*(object$type != "COX") 
			for (i in 1:ncoef)
			{
				cis[i,] = as.vector(quantile(bv$s.coef[,i+coffset], probs = c(ci[1],0.5,ci[2]), na.rm = TRUE,names = FALSE, type = 7));
			}
			coefficients=cbind(coefficients,cis,vres$uniTrainAccuracy,vres$redtrainAccuracy,vres$uniTrainAUC,vres$redtrainAUC,vres$IDIs,vres$NRIs,vres$z.IDIs,vres$z.NRIs);
			colnames(coefficients) <- c("Estimate","lower","median","upper","u.Accuracy","r.Accuracy","u.AUC","r.AUC","IDI","NRI","z.IDI","z.NRI");
			FRESAsummary <- list(coefficients=coefficients,Accuracy=vres$fullTrainAccuracy,tAUC=vres$fullTrainAUC,bootstrap=bv);
		}
	}
	return (FRESAsummary);
}
