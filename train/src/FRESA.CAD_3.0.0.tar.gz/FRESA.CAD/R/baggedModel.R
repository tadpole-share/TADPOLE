baggedModel <-
function(modelFormulas,data,type=c("LM","LOGIT","COX"),Outcome=NULL,timeOutcome=NULL,frequencyThreshold=0.01,univariate=NULL,useFreq=TRUE)
{
	type <- match.arg(type)

	loops <- length(modelFormulas);
	features <- vector();
	observations <- nrow(data);
	if (length(modelFormulas)>0)
	{
		iscompletef <- (gregexpr(pattern ='~',modelFormulas[1])[1]>0)
		if (iscompletef && is.null(Outcome))
		{
			varsmod <- all.vars(formula(modelFormulas[1]));
			if (substr(modelFormulas[1],1,5)!="Surv(")
			{
				Outcome <- varsmod[1];
			}
			else
			{
				Outcome <- varsmod[2];
				timeOutcome <- varsmod[1];
			}
		}

		theoutcome <- data[,Outcome];
		varOutcome <- var(theoutcome);
		binoutcome <- (length(table(theoutcome))==2) && (min(theoutcome)==0);
		predtype="linear";
		if (binoutcome) predtype="prob";
		if ( (type=="LM") && (binoutcome==TRUE) )
		{
			data[,Outcome] = 2*theoutcome-1.0;
		}
		
		if (type!="COX")
		{
			baseForm <- paste(Outcome,"~ 1");
		}
		else
		{
			baseForm <- paste("Surv(",timeOutcome,",",Outcome,")~ 1");
		}
		EquTrainSet <- data;
		minTrainSamples <- nrow(data);
		maxTrainSamples = minTrainSamples;
		casesample  <- NULL;
		controlsample <- NULL;
		noequalSets <- FALSE;
		nrowcases <- minTrainSamples
		nrowcontrols <- minTrainSamples
		if (type != "LM")
		{
			casesample = subset(data,get(Outcome)  == 1);
			controlsample = subset(data,get(Outcome) == 0);
			nrowcases <- nrow(casesample);
			nrowcontrols <- nrow(controlsample);
			
			minTrainSamples <- min(c(nrowcases,nrowcontrols));
			maxTrainSamples <- max(c(nrowcases,nrowcontrols));
			noequalSets <- (minTrainSamples < (0.75*maxTrainSamples));
	#		cat(nrowcases,":",nrowcontrols,":",noequalSets,"\n")
	#		cat(minTrainSamples,":",maxTrainSamples,":",noequalSets,"\n")
		}

		
		
		
		#	cat("Bagging\n")
		theterms <- list();
		for (n in 1:loops)
		{
			if (iscompletef)	
			{
				modelFormulas[n] <- unlist(strsplit(as.character(modelFormulas[n]),"[~]"))[2];
			}
			if (nchar(modelFormulas[n])>0)
			{
				modelFormulas[n] <- paste(baseForm,"+",modelFormulas[n]);
			}
			else
			{
				modelFormulas[n] <- baseForm;
			}
			termList <- str_replace_all(attr(terms(formula(modelFormulas[n])),"term.labels"),":","\\*");
			features <- append(features,termList);
			theterms[[n]] <- termList;
		}
		VarFrequencyTable <- table(features);
	#	print(modelFormulas);
			
		if (length(VarFrequencyTable)>1) 
		{
			if (!is.null(univariate))
			{
				VarFrequencyTable <- VarFrequencyTable[order(-univariate[rownames(VarFrequencyTable),"ZUni"])];			
			}
			if (useFreq)
			{
				VarFrequencyTable <- VarFrequencyTable[order(-VarFrequencyTable)]
			}
		}
		vnames <- rownames(VarFrequencyTable);
		formulaNetwork <- matrix(0,nrow=length(VarFrequencyTable),ncol = length(VarFrequencyTable))
		dimnames(formulaNetwork) <- list(names(VarFrequencyTable),names(VarFrequencyTable))
		m <- formulaNetwork
		Jaccard.SM <- 0;
		tota <- 0;
		for (n in 1:loops)
		{
			feat <- theterms[[n]];
			lft <- length(feat);
			m[,] <- 0;
			if (lft>0)
			{
				m[feat,feat]=1;
				if (n<loops)
				{
					for (i in (n+1):loops)
					{
						feat2 <- theterms[[i]];
						if (length(feat2) > 0)
						{
							Jaccard.SM = Jaccard.SM+sum(duplicated(c(feat2,feat)))/length(unique(c(feat2,feat)));
							tota = tota + 1;
	#						print(feat2)
	#						print(feat)
	#						cat("Dup:",sum(duplicated(c(feat2,feat)))," U:",length(unique(c(feat2,feat)))," JI:",Jaccard.SM,"\n")
						}
					}
				}
			}
			formulaNetwork <- formulaNetwork+m
		}
		if (tota>1) Jaccard.SM = Jaccard.SM/tota;
		formulaNetwork <- round(formulaNetwork/loops,digits = 3);

	#	cat("Size :",nrow(data)," Features :",length(VarFrequencyTable))
		
		nsize <- nrow(data)
		
		lastTopVariable = length(VarFrequencyTable);
		if (lastTopVariable >= (nsize-2)) lastTopVariable <- (nsize-2); #The largest model size
		
		frma <- baseForm;
		enterlist <- vector();
		toRemove <- vector();
		bmodelsize <- 1;
		removed <- 0;
		avgsize <- 0;
		coefEvolution <- NULL;
		if (length(vnames)>0)
		{
			thrsfreq <- as.integer(frequencyThreshold*VarFrequencyTable[1]+0.5);
			fistfreq <- VarFrequencyTable[1];
			for ( i in 1:length(vnames))
			{
				if ((vnames[i] != " ") && (vnames[i] != ""))
				{
					enterlist <- append(enterlist,vnames[i]);
					if ((i<=lastTopVariable)&&(VarFrequencyTable[i] >= thrsfreq))  # Only features with a given frequency
					{
						if ((fistfreq == loops)&&(VarFrequencyTable[i] > (loops/3)))
						{
							fistfreq <- VarFrequencyTable[i];
							thrsfreq <- as.integer(frequencyThreshold*fistfreq+0.5);
						}
						frma <- paste(frma,"+",vnames[i]);	
						bmodelsize = bmodelsize + 1;
					}
					else
					{
						toRemove <- append(toRemove,paste(" ",vnames[i]," ",sep=""));
						removed = removed+1;
					}
				}
			}
			cat("\nNum. Models:",loops," To Test:",length(vnames)," TopFreq:",fistfreq," Thrf:",thrsfreq," Removed:",removed,"\n")
			model <- modelFitting(formula(frma),data,type="LM",fast=TRUE);
			thevars <- all.vars(formula(frma));
			data <- data[,thevars];
			if (noequalSets)
			{
				casesample <- casesample[,thevars]
				controlsample <- controlsample[,thevars]
				trainCaseses <- casesample;
				trainControls <- controlsample;
		#		print(thevars);
			}
			else
			{
				EquTrainSet <- data;
			}
			
			
		#	print(toRemove);
		#	print(model$coefficients);
		#	cat(frma,"\n");
			if (inherits(model, "try-error"))
			{
				cat(frma," Warning Bagging Fitting error\n")
			}
			msize <- length(model$coefficients)
			basecoef <- abs(model$coefficients)+1e-6;
			names(basecoef) <- names(model$coefficients);
		#	print(basecoef);
			avgsize <- msize-1;
			mado <- NA;
			rnames <- 0;
			nrep <- 1+2*(noequalSets);
			if ((msize > 1)&&(loops>1))
			{
				model$type=type;
				onames <- names(model$coefficients);
				mmult <- 1+1*(type=="COX");
				model$estimations <- rep(0,mmult*msize); 
				wts <- 0;
				model$coefficients <- rep(0,msize);
				names(model$coefficients) <- onames;
				modelmeans <- model$coefficients;
				coefEvolution <- c(0,model$coefficients);
				names(coefEvolution) <- c("Weight",names(model$coefficients));
			#	cat("\n");
				avgsize = 0;
				for (n in 1:loops)
				{
					if ((n %% 10) == 0) cat(".");
					feat <- theterms[[n]]
					avgsize = avgsize+length(feat);
		#			cat(modelFormulas[n],"\n");

					if (length(toRemove)>0)
					{
						modelFormulas[n] <- paste(modelFormulas[n],"  ",sep="");
						for (rml in 1:length(toRemove))
						{
							modelFormulas[n] <- sub(toRemove[rml]," 1 ",modelFormulas[n],fixed=TRUE);
						}
	#					cat("After Rem:",modelFormulas[n],"\n");
						feat <- attr(terms(formula(modelFormulas[n])),"term.labels");
					}
					if (length(feat)>0)
					{
						for (replicates in 1:nrep)
						{
							if (noequalSets)
							{
								if (maxTrainSamples > nrowcases)  trainCaseses <- casesample[sample(1:nrowcases,maxTrainSamples,replace=TRUE),]
								if (maxTrainSamples > nrowcontrols)  trainControls <- controlsample[sample(1:nrowcontrols,maxTrainSamples,replace=TRUE),]
								EquTrainSet <- rbind(trainCaseses,trainControls)
								theoutcome <- EquTrainSet[,Outcome];
								varOutcome <- var(theoutcome);
								observations <- nrow(EquTrainSet);
							}
							out <- modelFitting(formula(modelFormulas[n]),EquTrainSet,type,fast=TRUE);
							
							if (!inherits(out, "try-error")) 
							{
								osize <- length(out$coefficients)					
								if (osize > 1)
								{
									curprediction <- predict.fitFRESA(out,EquTrainSet,predtype)
									residual <- as.vector(abs(curprediction-theoutcome));
									onames <- names(out$coefficients);

									if (predtype=="linear")
									{
										Rwts <- (varOutcome-sum(residual^2)/observations)/varOutcome; #Correlation
									}
									else
									{
										Rwts <- 2.0*(sum(1.0*(residual<0.5))/observations - 0.5); # 2*(ACC-0.5)
									}
		#							print(Rwts);
									if (Rwts<=0) Rwts <- 1.0e-3;
		#							print(basecoef[onames]);
		#							print(out$coefficients);
									Rwts <- as.vector(Rwts/sum(abs(out$coefficients/basecoef[onames]))) #by sum of weights
									rnames <- append(rnames,n*nrep+(replicates-1))
									outmeans <- out$coefficients;
									wts = wts + Rwts;
									model$coefficients[onames] <- model$coefficients[onames] + Rwts*out$coefficients[onames];
									coefEvolution <- rbind(coefEvolution,c(Rwts,model$coefficients/wts));
									if (type=="COX")
									{
										fullmodelmeans <- abs(modelmeans[onames]);
										names(fullmodelmeans) <- onames 
										for (ei in 1:osize) 
										{
											outmeans[ei] <- out$estimations[osize+ei];
										}
										for (ei in onames) 
										{
											if (fullmodelmeans[ei]>0)
											{
												modelmeans[ei] <- 0.5*(modelmeans[ei] + outmeans[ei]); 
											}
											else
											{
												modelmeans[ei] <- outmeans[ei]; 
											}
										}
									}
			#						print(model$coefficients)
								}
							}
							else
							{
								cat("+");
			#					print(out$coef);
							}
						}
					}
				}
				avgsize = avgsize/loops;
				if( wts>0)
				{
		#			print(model$coefficients)
					model$coefficients <- model$coefficients/wts;
					coefEvolution <- as.data.frame(coefEvolution);
					rownames(coefEvolution) <- rnames
					if (type == "COX")
					{
						model$estimations <- c(model$coefficients,modelmeans);
					}
					else
					{
						model$estimations <- model$coefficients;
					}
				}
				else
				{
					
					model <- modelFitting(formula(frma),data,type=type,fast=TRUE)
		#			print(model$coefficients)
					model$coefficients[is.nan(model$coefficients)] <- 0.0;
					model$coefficients[is.na(model$coefficients)] <- 0.0;
					model$estimations[is.nan(model$estimations)] <- 0.0;
					model$estimations[is.na(model$estimations)] <- 0.0;
				}
			}
			else
			{
				model <- modelFitting(formula(frma),data,type=type,fast=TRUE)
				model$coefficients[is.nan(model$coefficients)] <- 0.0;
				model$coefficients[is.na(model$coefficients)] <- 0.0;
				model$estimations[is.nan(model$estimations)] <- 0.0;
				model$estimations[is.na(model$estimations)] <- 0.0;
			}
		}
		else
		{
			model <- modelFitting(formula(frma),data,type=type,fast=TRUE);
		}
		# print(model$coefficients);
		environment(model$formula) <- globalenv()
		environment(model$terms) <- globalenv()
	}
	else
	{
		model <- NULL;
		frma <- NULL;
		VarFrequencyTable <- NULL;
		avgsize <- 0;
		formulaNetwork <- NULL;
		Jaccard.SM <- 0;
		coefEvolution <- NULL;
	}
	

  	result <- list(bagged.model=model,
				   formula=frma,
				   frequencyTable=VarFrequencyTable,
				   averageSize=avgsize,
				   formulaNetwork=formulaNetwork,
				   Jaccard.SM = Jaccard.SM,
				   coefEvolution=coefEvolution
				   );
  
	return (result);
}
