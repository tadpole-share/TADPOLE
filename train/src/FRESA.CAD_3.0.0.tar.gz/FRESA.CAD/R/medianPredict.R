medianPredict <-
function (formulaList,trainData,testData=NULL, predictType = c("prob", "linear"),type = c("LOGIT", "LM","COX","SVM"),Outcome=NULL,nk = 0) 
{

#	cat("Median\n")
#		print(formulaList);
	if (is.null(Outcome)) 
	{
		nk = -1;
#		for (i in 1:length(formulaList))
#		{
#			formulaList[i] <- paste(formulaList[i],"+1")
#		}
		varlist <- attr(terms(formula(formulaList[1])),"variables")
		
		dependent <- as.character(varlist[[2]])
		
		if (length(dependent)==3)
		{
			vOutcome = dependent[3];
		}
		else
		{
			vOutcome = dependent[1];
		}
	}
	else
	{
		vOutcome=Outcome;
		for (i in 1:length(formulaList))
		{
			if (gregexpr(pattern ='~',as.character(formulaList[i]))[1]>0)
			{
				feat <- unlist(strsplit(as.character(formulaList[i]),"[~]"));
				if (nchar(feat[2])>0)
				{
					formulaList[i] <- feat[2];
				}
				else
				{
					formulaList[i] <- "1";
				}
			}
		}
	}
	EquTrainSet <- trainData;
	minTrainSamples <- nrow(trainData);
	maxTrainSamples = minTrainSamples;
	casesample  <- NULL;
	controlsample <- NULL;
	noequalSets <- FALSE;
	nrowcases <- minTrainSamples
	nrowcontrols <- minTrainSamples
	if ((type == "LOGIT") || (type == "COX"))
	{
		casesample = subset(trainData,get(vOutcome)  == 1);
		controlsample = subset(trainData,get(vOutcome) == 0);
		trainCaseses <- casesample;
		trainControls <- controlsample;
		nrowcases <- nrow(casesample);
		nrowcontrols <- nrow(controlsample);
		
		minTrainSamples <- min(nrow(casesample),nrow(controlsample));
		maxTrainSamples <- max(nrow(casesample),nrow(controlsample));
		noequalSets <- (minTrainSamples < 0.90*maxTrainSamples);
	}
	
	if (nk==0)
	{
		nk = 2*as.integer(sqrt(minTrainSamples/2)) + 1;
	}
	if (is.null(testData))
	{
		medianKNN=NULL;
		out=NULL;
		KNNpredictions=NULL;
		outKNN=NULL;
		medianout <- vector(mode="numeric",length = nrow(trainData));
		cat("\n");
		for ( n in 1:nrow(trainData))
		{
			if ((n %% 10)==0) cat(".");
			mp <- medianPredict(formulaList,trainData[-n,],trainData[n,],predictType,type,Outcome,nk = -1)
			medianout[n] = mp$medianPredict[1]
			out <- rbind(out,cbind(trainData[n,vOutcome],mp$predictions[1,-1]));
		}
		rownames(out) <- rownames(trainData);
		cat("\n");
	}
	else
	{	
		out <- NULL;
		if (!is.null(Outcome)) 
		{
			if (nchar(formulaList[[1]])>0)
			{
				ftmp <- formula(paste(Outcome,"~ 1+",formulaList[[1]]))
			}
			else
			{
				ftmp <- formula(paste(Outcome,"~ 1"));
			}
		}
		else
		{
			ftmp <- formula(formulaList[1])
		}
		if (noequalSets)
		{
			if (maxTrainSamples > nrowcases)  trainCaseses <- casesample[sample(1:nrowcases,maxTrainSamples,replace=TRUE),]
			if (maxTrainSamples > nrowcontrols)  trainControls <- controlsample[sample(1:nrowcontrols,maxTrainSamples,replace=TRUE),]
			EquTrainSet <- rbind(trainCaseses,trainControls)
		}
		if (nk>0)
		{
			outKNN <- cbind(testData[,vOutcome],getKNNpredictionFromFormula(ftmp,EquTrainSet,testData,Outcome=vOutcome,nk)$binProb)
			rownames(outKNN) <- rownames(testData);
		}
		else
		{
			outKNN <- NULL;
			medianKNN <- NULL;
		}

		bestmodel <- modelFitting(ftmp,EquTrainSet,type,fast=TRUE)	
		totSamples <- cbind(testData[,vOutcome],predict.fitFRESA(bestmodel,testData,predictType));
		rownames(totSamples) <- rownames(testData);
		out <- totSamples;
		if (length(formulaList)>1)
		{
			for (i in 2:length(formulaList))
			{
				if (!is.null(Outcome))
				{		
					if (nchar(formulaList[[i]])>0)
					{
						ftmp <- formula(paste(Outcome,"~1+",formulaList[[i]]));
					}
					else
					{
						ftmp <- formula(paste(Outcome,"~1"));
					}
				}
				else
				{
					ftmp <- formula(formulaList[i]);
				}
				if (noequalSets)
				{
					if (maxTrainSamples > nrowcases)  trainCaseses <- casesample[sample(1:nrowcases,maxTrainSamples,replace=TRUE),]
					if (maxTrainSamples > nrowcontrols)  trainControls <- controlsample[sample(1:nrowcontrols,maxTrainSamples,replace=TRUE),]
					EquTrainSet <- rbind(trainCaseses,trainControls)
				}
				if (nk>0) 
				{
					outKNN <- cbind(outKNN,getKNNpredictionFromFormula(ftmp,EquTrainSet,testData,Outcome=vOutcome,nk)$binProb);
				}
				fm <- modelFitting(ftmp,EquTrainSet,type,fast=TRUE)
				if (inherits(fm, "try-error"))
				{
					if (noequalSets)
					{
						if (maxTrainSamples > nrowcases)  trainCaseses <- casesample[sample(1:nrowcases,maxTrainSamples,replace=TRUE),]
						if (maxTrainSamples > nrowcontrols)  trainControls <- controlsample[sample(1:nrowcontrols,maxTrainSamples,replace=TRUE),]
						EquTrainSet <- rbind(trainCaseses,trainControls)
					}
					fm <- modelFitting(ftmp,EquTrainSet,type,fast=TRUE)
				}
				out <- cbind(out,predict.fitFRESA(fm,testData,predictType));
			}
			out <- as.data.frame(out);
			medianout <- rowMedians(out[,-1],na.rm = TRUE);
			if (nk>0) 
			{
				outKNN <- as.data.frame(outKNN);
				medianKNN <- rowMedians(outKNN[,-1],na.rm = TRUE);
			}
		}
		else
		{
			out <- as.data.frame(out);
			medianout <- out[,-1];
			if (nk>0) 
			{
				outKNN <- as.data.frame(outKNN);
				medianKNN <- outKNN[,-1];
			}
		}
	}
	result <- list(medianPredict=medianout,
	medianKNNPredict=medianKNN,predictions=out,KNNpredictions=outKNN)
    return (result)
}