getSignature <-
function(data,varlist=NULL,Outcome=NULL,target=c("All","Control","Case"),CVFolds=5,repeats=5,distanceFunction=signatureDistance,...)
{
#It will use a back elimination procedure to return the list of features that maximize the CV ROC AUC based on a nearest centroid scheme.
#varlist a list of candidate features
#data the data frame where a binary outcome is defined 
#CVfolds the number of folds to be used
#the number of repetitions of each CV folds
#distanceFunction is funtion that returns the distance betweeen the signature template and each row of a dataframe
#... parameters to the distanceFuntion


CVDistance <- function (casesample,controlsample,CVFolds,totRepeats,target)
{
	controlDistance <- numeric();
	caseDistance <- numeric();
	outcomes <-  numeric();
	IDs <- character();
	for (i in 1:totRepeats) 
	{
		j <- 1 + ((i-1) %% CVFolds)
		if ( j == 1)
		{
			casefolds <- cvTools::cvFolds(casesamplesize, CVFolds,1,  "random");
			controlfolds <- cvTools::cvFolds(controlsamplesize, CVFolds,1,  "random");
		}
		CaseTrainSet <- casesample[casefolds$subsets[casefolds$which != j,],];
		CaseBlindSet <- casesample[casefolds$subsets[casefolds$which == j,],];
		ControlTrainSet <- controlsample[controlfolds$subsets[controlfolds$which != j,],];
		ControlBlindSet <- controlsample[controlfolds$subsets[controlfolds$which == j,],];
		testData <- rbind(CaseBlindSet,ControlBlindSet);
		signatureTemplate <- colMeans(ControlTrainSet,na.rm=TRUE);
		controlDistance <- append(controlDistance,distanceFunction(signatureTemplate,testData,...));
		signatureTemplate <- colMeans(CaseTrainSet,na.rm=TRUE);
		caseDistance <- append(caseDistance,distanceFunction(signatureTemplate,testData,...));
		outcomes <- append(outcomes,c(rep(1,nrow(CaseBlindSet)),rep(0,nrow(ControlBlindSet))));
		IDs <- append(IDs,rownames(testData));
	}

	if (target=="Control") 
	{
		distance = controlDistance;
	}
	else
	{
		if (target=="Case") 
		{
			distance = caseDistance;
		}
		else
		{
			distance = caseDistance-controlDistance;
		}
	}
	cont <- distance[outcomes==0];
	case <- distance[outcomes==1];
	cAUC <- pROC::roc(outcomes,distance,auc=TRUE)$auc
	zdis <- abs(mean(case,na.rm=TRUE)-mean(cont,na.rm=TRUE))/sqrt(1.0e-10+(var(case,na.rm=TRUE)+var(cont,na.rm=TRUE))/2);

	result <- list(	controlDistance=controlDistance,
					caseDistance=caseDistance,
					outcomes=outcomes,
					IDs=IDs,
					cAUC=cAUC,
					zdis=zdis
					);
	return (result);
}
	
	if (is.null(varlist)) varlist=colnames(data);
	target <- match.arg(target);
	if (is.null(Outcome))
	{
		Outcome=varlist[1];
		varlist <- varlist[-1];
	}
	casesample = subset(data[,c(Outcome,varlist)],get(Outcome)  == 1);
	controlsample = subset(data[,c(Outcome,varlist)],get(Outcome) == 0);
	casesamplesize <- nrow(casesample);
	controlsamplesize <- nrow(controlsample);
	featuresize <- length(varlist);
	stsize <- min(5,featuresize-1);
	lastFeatureSize <- featuresize;
	totRepeats <- CVFolds*repeats;
	AUCevolution <- numeric();
	Zevolution <- numeric();
	featureSizeEvolution <- numeric();
	ES=0;
	maxES <- 0;
	maxAUC <- 0;
	mmasES <- 0;
	oldES <-0;
	keepfeature <- character();
	bestkeep <- character();
	CVOutput <- NULL;
# drop backfeatures
	while ((ES >= 0.95*oldES) && (featuresize>stsize))
	{	
		oldES <- ES;
		snames <- varlist[1:featuresize];
		cvdis <- CVDistance(casesample[,snames],controlsample[,snames],CVFolds,totRepeats,target);
		sz <- length(snames);
#		ES <- (0.01*cvdis$zdis + 0.99*cvdis$cAUC)*(sz-1)/sz;
		ES <- (0.01*cvdis$zdis + 0.99*cvdis$cAUC);
		if (ES >= maxES) 
		{
			maxES <- ES;
			maxAUC <- cvdis$cAUC;
			mmasES <- ES;
			bestkeep <- snames;
			lastFeatureSize <- featuresize
			CVOutput <- data.frame(cvdis$IDs,cvdis$outcomes,cvdis$caseDistance,cvdis$controlDistance);
		}
		else
		{
			if (cvdis$cAUC >= 0.98*maxAUC) 
			{
				mmasES <- ES;
				bestkeep <- snames;
				lastFeatureSize <- featuresize
				CVOutput <- data.frame(cvdis$IDs,cvdis$outcomes,cvdis$caseDistance,cvdis$controlDistance);
			}
		}
		
		AUCevolution <- append(AUCevolution,cvdis$cAUC);
		Zevolution <- append(Zevolution,cvdis$zdis);
		featureSizeEvolution <- append(featureSizeEvolution,featuresize);
		cat(sprintf("%4d %s %4d %s %8.3f %s %8.3f %s %8.3f\n",featuresize,"Number of features:",lastFeatureSize,"Max AUC:",maxAUC,"AUC:",cvdis$cAUC,"Z:",cvdis$zdis));
		step <- as.integer(featuresize/25+0.5);
		if (step<1) step=1;
		featuresize <- featuresize-step;
	}
	sz <- length(bestkeep);
	maxES <- mmasES*(sz-1)/sz;;
# Drop forward features
	keepfeature <- bestkeep;
	removed <- numeric();
	for (i in 1:lastFeatureSize)
	{	
		snames <- keepfeature[-c(removed,i)];
		cvdis <- CVDistance(casesample[,snames],controlsample[,snames],CVFolds,totRepeats,target);
		sz <- length(snames);
		ES <- (0.01*cvdis$zdis + 0.99*cvdis$cAUC)*(sz-1)/sz;
		if (ES >= maxES) 
		{
			bestkeep <- snames;
			removed <- c(removed,i);
			CVOutput <- data.frame(cvdis$IDs,cvdis$outcomes,cvdis$caseDistance,cvdis$controlDistance);
			maxES <- ES
			maxAUC <- cvdis$cAUC;
		}
		AUCevolution <- append(AUCevolution,cvdis$cAUC);
		Zevolution <- append(Zevolution,cvdis$zdis);
		featureSizeEvolution <- append(featureSizeEvolution,i);
		cat(sprintf("%4d %s %4d %s %8.3f %s %8.3f %s %8.3f\n",i,"Number of features:",length(bestkeep),"Max AUC:",maxAUC,"AUC:",cvdis$cAUC,"Z:",cvdis$zdis));
	}
	if (lastFeatureSize<length(varlist))
	{
		fowardkeep <- bestkeep;
		keepfeature <- character();
		featureID=lastFeatureSize+1;
		rdeltaES <- 0.1;
		oldES <- maxES;
		sizef <- length(bestkeep);
		stop <- FALSE
		while (!stop)
		{	
			snames <- c(fowardkeep,keepfeature,varlist[featureID]);
			cvdis <- CVDistance(casesample[,snames],controlsample[,snames],CVFolds,totRepeats,target);
			sz <- length(snames);
			ES <- (0.01*cvdis$zdis + 0.99*cvdis$cAUC)*(sz-1)/sz;
			if (ES >= maxES) 
			{
				keepfeature <- append(keepfeature,varlist[featureID]);
				bestkeep <- snames;
				sizef <- length(snames);
				CVOutput <- data.frame(cvdis$IDs,cvdis$outcomes,cvdis$caseDistance,cvdis$controlDistance);
				rdeltaES <- 0.9*rdeltaES+0.01;
				if (cvdis$cAUC >= maxAUC)
				{
					maxES <- ES;
					maxAUC <- cvdis$cAUC
				}
			}
			else
			{
				rdeltaES <- 0.8*rdeltaES+0.2*(maxES-oldES)/maxES;
			}
			cat(sprintf("%4d %s %4d %s %8.3f %s %8.3f %s %8.3f %s %8.5f \n",featureID,"Number of features:",sizef,"Max AUC:",maxAUC,"AUC:",cvdis$cAUC,"Z:",cvdis$zdis,"Rdelta:",rdeltaES));
			AUCevolution <- append(AUCevolution,cvdis$cAUC);
			Zevolution <- append(Zevolution,cvdis$zdis);
			featureSizeEvolution <- append(featureSizeEvolution,featureID);
			featureID <- featureID+1;
			if ((rdeltaES < 1.0e-4) || (featureID>length(varlist)))
			{
				stop <- TRUE;
			}
			oldES <- maxES;
		}
	}
	

	colnames(CVOutput) <- c("ID","Outcome","Case.Distance","Control.Distance");
	Ntemplate <- colMeans(controlsample[,bestkeep],na.rm=TRUE);
	Ptemplate <- colMeans(casesample[,bestkeep],na.rm=TRUE);

	
	result <- list(controlTemplate=Ntemplate,
				   caseTamplate=Ptemplate,
				   AUCevolution=AUCevolution,
				   Zevolution=Zevolution,
				   featureSizeEvolution=featureSizeEvolution,
				   featureList=bestkeep,
				   CVOutput=CVOutput,
				   maxES=maxES
				   );
  
	return (result);
}
